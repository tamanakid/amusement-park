package parque.pulseras;


/**
 * @author DTE-SSOO 2019-20  
 */
public class Pulsera
{
	
	int tiques;

	/**
	 * Constructor de pulsera 
	 */
	Pulsera (int tiques)
	{
		this.tiques = tiques;
	}
}
